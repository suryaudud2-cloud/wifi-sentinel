package com.wifisentinel

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.location.LocationManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.Locale

private val Navy = Color(0xFF081426)
private val Panel = Color(0xFF12243B)
private val Cyan = Color(0xFF38D9F5)
private val Muted = Color(0xFF9FB2C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SentinelApp() }
    }
}

data class WifiItem(val ssid: String, val bssid: String, val security: String, val level: Int, val frequency: Int)
data class DeviceItem(val ip: String, val reachable: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SentinelApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var wifiItems by remember { mutableStateOf<List<WifiItem>>(emptyList()) }
    var scanMessage by remember { mutableStateOf("Tekan Pindai untuk melihat jaringan di sekitar.") }
    var scanning by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var wpsEnabled by remember { mutableStateOf(false) }
    var routerSecurity by remember { mutableStateOf("WPA2 / WPA3") }
    var devices by remember { mutableStateOf<List<DeviceItem>>(emptyList()) }
    var deviceMessage by remember { mutableStateOf("Pemindaian hanya untuk jaringan lokal yang Anda kelola.") }
    var deviceScanning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val permissions = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }.toTypedArray()
    }
    var hasPermission by remember {
        mutableStateOf(permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED })
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasPermission = permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Color(0xFF73E6C3), background = Navy,
            surface = Panel, onPrimary = Navy, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("WIFI SENTINEL", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                            Text("SECURITY AUDITOR", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy),
                    actions = { Icon(Icons.Default.Shield, contentDescription = null, tint = Cyan, modifier = Modifier.padding(end = 18.dp).size(28.dp)) }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val labels = listOf("Home", "WiFi", "Password", "Router", "Devices")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Wifi, Icons.Default.Key, Icons.Default.Security, Icons.Default.Devices)
                    labels.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF1C3A56), unselectedTextColor = Muted)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when (tab) {
                    0 -> HomeScreen(
                        wifiCount = wifiItems.size,
                        passwordScore = passwordScore(password),
                        security = routerSecurity,
                        deviceCount = devices.size,
                        onScan = { tab = 1 },
                        onAudit = { tab = 3 }
                    )
                    1 -> WifiScreen(
                        items = wifiItems, message = scanMessage, scanning = scanning,
                        onScan = {
                            if (!hasPermission) permissionLauncher.launch(permissions)
                            else {
                                scope.launch {
                                    scanning = true
                                    scanMessage = "Memindai jaringan WiFi…"
                                    val result = scanWifi(context)
                                    wifiItems = result.first
                                    scanMessage = result.second
                                    scanning = false
                                }
                            }
                        }
                    )
                    2 -> PasswordScreen(password, { password = it }, showPassword, { showPassword = it })
                    3 -> RouterScreen(routerSecurity, { routerSecurity = it }, wpsEnabled, { wpsEnabled = it }, passwordScore(password))
                    else -> DevicesScreen(
                        devices, deviceMessage, deviceScanning,
                        onScan = {
                            scope.launch {
                                deviceScanning = true
                                deviceMessage = "Memeriksa perangkat pada subnet lokal…"
                                val result = scanLocalDevices(context)
                                devices = result.first
                                deviceMessage = result.second
                                deviceScanning = false
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(wifiCount: Int, passwordScore: Int, security: String, deviceCount: Int, onScan: () -> Unit, onAudit: () -> Unit) {
    val score = ((passwordScore * 0.4) + (if (security.contains("WPA2") || security.contains("WPA3")) 35 else 10) + 20).toInt().coerceIn(0, 100)
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 20.dp)) {
        item {
            Text("Dashboard keamanan", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Ringkasan pemeriksaan jaringan Anda", color = Muted, fontSize = 13.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ESTIMASI SECURITY SCORE", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("$score", color = Cyan, fontSize = 62.sp, fontWeight = FontWeight.Black)
                    Text(if (score >= 80) "Relatif aman" else if (score >= 60) "Perlu ditingkatkan" else "Perlu pemeriksaan", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Color(0xFF29415B))
                    Spacer(Modifier.height(8.dp))
                    Text("Skor awal berdasarkan data yang tersedia, bukan sertifikasi keamanan.", color = Muted, fontSize = 10.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Jaringan ditemukan", wifiCount.toString(), Icons.Default.Wifi, Modifier.weight(1f))
                MetricCard("Perangkat terlihat", deviceCount.toString(), Icons.Default.Devices, Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mulai audit", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Pindai jaringan sekitar atau periksa konfigurasi router Anda.", color = Muted, fontSize = 13.sp)
                    Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("Pindai WiFi") }
                    OutlinedButton(onClick = onAudit, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Security, null); Spacer(Modifier.width(8.dp)); Text("Audit router") }
                }
            }
        }
        item { Text("Catatan: gunakan hanya pada jaringan yang Anda miliki atau berizin untuk diuji.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Cyan)
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun WifiScreen(items: List<WifiItem>, message: String, scanning: Boolean, onScan: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("WiFi Scanner", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Jaringan yang terdeteksi oleh perangkat Android.", color = Muted, fontSize = 13.sp)
        Button(onClick = onScan, enabled = !scanning, modifier = Modifier.fillMaxWidth()) {
            if (scanning) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Search, null)
            Spacer(Modifier.width(8.dp)); Text(if (scanning) "Memindai…" else "Pindai jaringan")
        }
        Text(message, color = Muted, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, null, tint = Cyan)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.ssid.ifBlank { "(SSID tersembunyi)" }, fontWeight = FontWeight.Bold)
                                Text(item.bssid, color = Muted, fontSize = 10.sp)
                            }
                            Text("${item.level} dBm", color = Cyan, fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = {}, label = { Text(item.security) })
                            AssistChip(onClick = {}, label = { Text("${item.frequency} MHz") })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PasswordScreen(password: String, onPassword: (String) -> Unit, visible: Boolean, onVisible: (Boolean) -> Unit) {
    val score = passwordScore(password)
    val advice = passwordAdvice(password)
    Column(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Password Analyzer", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Analisis dilakukan di perangkat ini. Password tidak dikirim ke internet.", color = Muted, fontSize = 13.sp)
        OutlinedTextField(
            value = password, onValueChange = onPassword, modifier = Modifier.fillMaxWidth(),
            label = { Text("Masukkan password WiFi") },
            visualTransformation = if (visible) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { IconButton(onClick = { onVisible(!visible) }) { Icon(if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, focusedLabelColor = Cyan)
        )
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Kekuatan password", color = Muted)
                Text(if (password.isBlank()) "—" else "$score / 100", color = Cyan, fontSize = 38.sp, fontWeight = FontWeight.Black)
                LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Color(0xFF29415B))
                Text(if (password.isBlank()) "Masukkan password untuk memulai analisis." else passwordLabel(score), fontWeight = FontWeight.SemiBold)
                advice.forEach { Text("• $it", color = Muted, fontSize = 13.sp) }
            }
        }
        Text("Tips: gunakan password unik minimal 14–16 karakter, hindari nama, tanggal lahir, dan kata umum.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun RouterScreen(security: String, onSecurity: (String) -> Unit, wps: Boolean, onWps: (Boolean) -> Unit, passwordScore: Int) {
    Column(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Router Security Audit", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Isi berdasarkan pengaturan router atau halaman admin router Anda.", color = Muted, fontSize = 13.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Jenis keamanan WiFi", fontWeight = FontWeight.Bold)
                listOf("WPA3", "WPA2 / WPA3", "WPA2", "WPA / WEP", "Open / tanpa password", "Belum diketahui").forEach { option ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = security == option, onClick = { onSecurity(option) })
                        Text(option)
                    }
                }
                Divider(color = Color(0xFF29415B))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("WPS aktif?", fontWeight = FontWeight.Bold)
                        Text("Aktifkan jika WPS menyala di router.", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = wps, onCheckedChange = onWps)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Temuan awal", fontWeight = FontWeight.Bold)
                AuditLine("Jenis enkripsi", if (security == "WPA3" || security == "WPA2 / WPA3") "Baik" else if (security == "WPA2") "Cukup" else "Perlu ditinjau")
                AuditLine("WPS", if (wps) "Aktif — disarankan nonaktif" else "Nonaktif / belum dikonfirmasi")
                AuditLine("Password", if (passwordScore >= 70) "Kuat menurut pemeriksaan lokal" else "Belum kuat / belum diuji")
                Text("Pemeriksaan ini berdasarkan input manual, bukan pembacaan langsung konfigurasi router.", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun AuditLine(label: String, result: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 13.sp)
        Text(result, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun DevicesScreen(devices: List<DeviceItem>, message: String, scanning: Boolean, onScan: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Connected Devices", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Pemeriksaan host pada subnet lokal perangkat ini.", color = Muted, fontSize = 13.sp)
        Button(onClick = onScan, enabled = !scanning, modifier = Modifier.fillMaxWidth()) {
            if (scanning) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Radar, null)
            Spacer(Modifier.width(8.dp)); Text(if (scanning) "Memeriksa…" else "Pindai perangkat lokal")
        }
        Text(message, color = Muted, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices) { device ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Devices, null, tint = Cyan)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(device.ip, fontWeight = FontWeight.Bold)
                            Text("Respons jaringan terdeteksi", color = Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF73E6C3))
                    }
                }
            }
        }
    }
}

private suspend fun scanWifi(context: Context): Pair<List<WifiItem>, String> = withContext(Dispatchers.IO) {
    try {
        val manager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val locationOn = if (Build.VERSION.SDK_INT >= 28) locationManager.isLocationEnabled else true
        if (!manager.isWifiEnabled) return@withContext emptyList<WifiItem>() to "WiFi perangkat sedang mati."
        if (!locationOn) return@withContext emptyList<WifiItem>() to "Aktifkan layanan lokasi Android agar hasil scan tersedia."
        manager.startScan()
        val results = manager.scanResults ?: emptyList()
        val list = results.map { r ->
            val caps = r.capabilities.uppercase(Locale.ROOT)
            val security = when {
                caps.contains("SAE") || caps.contains("WPA3") -> "WPA3"
                caps.contains("WPA2") -> "WPA2"
                caps.contains("WPA") -> "WPA"
                caps.contains("WEP") -> "WEP"
                else -> "Open"
            }
            WifiItem(r.SSID, r.BSSID ?: "BSSID tidak tersedia", security, r.level, r.frequency)
        }.distinctBy { it.bssid }.sortedByDescending { it.level }
        if (list.isEmpty()) emptyList<WifiItem>() to "Belum ada hasil. Coba lagi dan pastikan izin serta lokasi aktif."
        else list to "${list.size} jaringan ditemukan. Hasil mengikuti batasan pemindaian Android."
    } catch (e: SecurityException) {
        emptyList<WifiItem>() to "Izin lokasi/perangkat sekitar belum diberikan."
    } catch (e: Exception) {
        emptyList<WifiItem>() to "Pemindaian gagal: ${e.localizedMessage ?: "kesalahan tidak diketahui"}"
    }
}

private suspend fun scanLocalDevices(context: Context): Pair<List<DeviceItem>, String> = withContext(Dispatchers.IO) {
    try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val network = cm.activeNetwork ?: return@withContext emptyList<DeviceItem>() to "Tidak ada jaringan aktif."
        val props = cm.getLinkProperties(network) ?: return@withContext emptyList<DeviceItem>() to "Informasi jaringan tidak tersedia."
        val route = props.routes.firstOrNull { it.isDefaultRoute && it.gateway is InetAddress }
            ?: return@withContext emptyList<DeviceItem>() to "Gateway lokal tidak ditemukan."
        val gateway = route.gateway as InetAddress
        val bytes = gateway.address
        if (bytes.size != 4) return@withContext emptyList<DeviceItem>() to "Pemindaian otomatis saat ini mendukung IPv4 lokal."
        val prefix = "${bytes[0].toInt() and 255}.${bytes[1].toInt() and 255}.${bytes[2].toInt() and 255}"
        val found = (1..254).mapNotNull { host ->
            val ip = "$prefix.$host"
            try {
                if (ip == gateway.hostAddress) DeviceItem(ip, true)
                else if (InetAddress.getByName(ip).isReachable(180)) DeviceItem(ip, true)
                else null
            } catch (_: Exception) { null }
        }
        found to if (found.isEmpty()) "Tidak ada host yang merespons. Sebagian perangkat mungkin memblokir ping." else "${found.size} host merespons. Ini bukan daftar lengkap semua perangkat."
    } catch (e: Exception) {
        emptyList<DeviceItem>() to "Pemindaian gagal: ${e.localizedMessage ?: "kesalahan jaringan"}"
    }
}

private fun passwordScore(value: String): Int {
    if (value.isBlank()) return 0
    var score = 0
    score += (value.length * 4).coerceAtMost(40)
    if (value.any { it.isLowerCase() }) score += 10
    if (value.any { it.isUpperCase() }) score += 10
    if (value.any { it.isDigit() }) score += 10
    if (value.any { !it.isLetterOrDigit() }) score += 15
    if (value.length >= 16) score += 15
    if (value.lowercase() in listOf("password", "12345678", "qwerty123", "admin123")) score = 5
    if (value.toSet().size <= 2) score = (score - 25).coerceAtLeast(0)
    return score.coerceIn(0, 100)
}
private fun passwordLabel(score: Int) = when {
    score >= 80 -> "Kuat"
    score >= 60 -> "Cukup kuat"
    score >= 35 -> "Lemah"
    else -> "Sangat lemah"
}
private fun passwordAdvice(value: String): List<String> {
    if (value.isBlank()) return listOf("Gunakan 16 karakter atau lebih.", "Campurkan huruf, angka, dan simbol.", "Hindari informasi pribadi dan pola umum.")
    return buildList {
        if (value.length < 16) add("Tambah panjang password menjadi minimal 16 karakter.")
        if (!value.any(Char::isUpperCase) || !value.any(Char::isLowerCase)) add("Campurkan huruf besar dan huruf kecil.")
        if (!value.any(Char::isDigit)) add("Tambahkan angka.")
        if (!value.any { !it.isLetterOrDigit() }) add("Tambahkan simbol.")
        if (value.lowercase() in listOf("password", "12345678", "qwerty123", "admin123")) add("Password ini termasuk pola yang sangat umum.")
        if (isEmpty()) add("Kombinasi terlihat baik. Pastikan password unik dan tidak digunakan ulang.")
    }
}
