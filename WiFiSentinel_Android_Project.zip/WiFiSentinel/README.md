# WiFi Sentinel — Android

Aplikasi audit keamanan WiFi untuk jaringan milik sendiri / yang telah memberi izin.

## Fitur pada versi 1.0
- Dashboard dengan skor estimasi.
- Pemindai SSID, BSSID, sinyal, frekuensi, dan jenis keamanan yang diumumkan access point.
- Analisis kekuatan password secara lokal (tidak mengirim password ke server).
- Checklist audit router berbasis input manual.
- Pemindaian host IPv4 pada subnet lokal menggunakan `isReachable` (hasil tidak selalu lengkap).

## Persyaratan
- Android Studio terbaru yang mendukung Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
- Minimum Android 10 (API 29).

## Membuka project
1. Ekstrak ZIP.
2. Android Studio → **Open** → pilih folder `WiFiSentinel`.
3. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK 35 dan JDK 17.
4. Hubungkan HP Android dengan USB debugging aktif.
5. Tekan **Run** untuk instalasi langsung, atau lanjutkan untuk membuat APK.

## Membuat APK
1. Android Studio → **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
2. Setelah selesai, klik **locate** pada notifikasi build.
3. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
4. Pindahkan APK ke HP dan instal. Izinkan instalasi dari sumber tersebut bila Android memintanya.

Untuk APK rilis: **Build → Generate Signed Bundle / APK → APK**, buat keystore sendiri, simpan backup keystore dan password dengan aman, lalu pilih `release`.

## Izin Android
- `ACCESS_FINE_LOCATION`: diperlukan oleh API hasil scan WiFi pada banyak perangkat Android.
- `NEARBY_WIFI_DEVICES`: diminta pada Android 13+ untuk kompatibilitas izin perangkat sekitar.
- `ACCESS_WIFI_STATE` dan `CHANGE_WIFI_STATE`: membaca/meminta scan WiFi.
- `ACCESS_NETWORK_STATE` dan `INTERNET`: membaca informasi jaringan dan pemeriksaan host lokal.

## Batasan penting
- Android membatasi frekuensi scan WiFi; `startScan()` dapat dibatasi dan hasil bisa berupa cache.
- Pada Android 10+, hasil scan WiFi dapat membutuhkan Location Services aktif dan izin lokasi.
- Aplikasi tidak dapat membaca password WiFi tersimpan dari sistem Android.
- Device scanner hanya menampilkan host yang merespons pemeriksaan; perangkat yang memblokir ping tidak akan terdeteksi.
- Audit router pada versi ini berbasis input manual, bukan akses otomatis ke panel admin router.
- Skor adalah indikator edukatif sederhana, bukan hasil penetration test atau sertifikasi.
- Gunakan hanya pada jaringan yang Anda miliki atau punya izin tertulis untuk menguji.

## Catatan pengembangan
Versi ini sengaja tidak melakukan deauthentication, packet injection, brute force, atau mencoba mengakses jaringan tanpa izin.
